PROGRESS3D SOURCE CODE
======================

	Thanks for downloading Progress3D(source code).
	
	Progress3D is a control with help of which you can give your program an advanced look by displaying Progress Bar in 3D.
	
	This was just a testing project and you can modify the codes and use them in anyway(if you made something good please send me a copy too :-)
	
	Please send comments/bugs/ideas at- 
			himanshu_mishra007@yahoo.co.in

	Site from where this .zip was downloaded- 
			http://newcodes.topcities.com/


If you are also a TurboC/C++ programmer you can download few of my codes such as -
	1) SNAKE
	2) CLOCK
	3) PIANO	
from 
	www.codearchive.com

	(If you found many see the author's name: Himanshu Mishra)

History

-> 11 August, 2005
*Now you can see your progress without any extra code
*Fixed some bugs

-> 23 June, 2005
*The first released version